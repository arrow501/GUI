package Ables;

interface Speakable {
    String speak();
}