package Figures;

public interface Calculate {
    double getArea();
    double getPerimeter();
}
