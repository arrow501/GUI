package Figures;

public interface Draw {
    void rysuj();
}
