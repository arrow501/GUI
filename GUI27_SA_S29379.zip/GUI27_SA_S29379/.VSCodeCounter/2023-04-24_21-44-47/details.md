# Details

Date : 2023-04-24 21:44:47

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 19 files,  334 codes, 39 comments, 92 blanks, all 465 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 10 | 0 | 9 | 19 |
| [bin/Cennik/Cennik.class](/bin/Cennik/Cennik.class) | Java | 27 | 0 | 0 | 27 |
| [bin/Cennik/CennikItem.class](/bin/Cennik/CennikItem.class) | Java | 9 | 0 | 0 | 9 |
| [bin/Dane/Klient.class](/bin/Dane/Klient.class) | Java | 13 | 0 | 0 | 13 |
| [bin/Dane/Koszyk.class](/bin/Dane/Koszyk.class) | Java | 14 | 0 | 0 | 14 |
| [bin/Dane/ListaZyczen.class](/bin/Dane/ListaZyczen.class) | Java | 5 | 0 | 0 | 5 |
| [bin/Dane/Program.class](/bin/Dane/Program.class) | Java | 10 | 0 | 0 | 10 |
| [bin/Dane/Programy.class](/bin/Dane/Programy.class) | Java | 13 | 0 | 0 | 13 |
| [bin/Gatunki/Dramat.class](/bin/Gatunki/Dramat.class) | Java | 6 | 0 | 0 | 6 |
| [bin/VODTest.class](/bin/VODTest.class) | Java | 31 | 0 | 1 | 32 |
| [src/Cennik/Cennik.java](/src/Cennik/Cennik.java) | Java | 35 | 0 | 13 | 48 |
| [src/Cennik/CennikItem.java](/src/Cennik/CennikItem.java) | Java | 36 | 0 | 9 | 45 |
| [src/Dane/Klient.java](/src/Dane/Klient.java) | Java | 16 | 0 | 5 | 21 |
| [src/Dane/Koszyk.java](/src/Dane/Koszyk.java) | Java | 9 | 0 | 2 | 11 |
| [src/Dane/ListaZyczen.java](/src/Dane/ListaZyczen.java) | Java | 3 | 0 | 3 | 6 |
| [src/Dane/Program.java](/src/Dane/Program.java) | Java | 29 | 0 | 10 | 39 |
| [src/Dane/Programy.java](/src/Dane/Programy.java) | Java | 17 | 0 | 7 | 24 |
| [src/Gatunki/Dramat.java](/src/Gatunki/Dramat.java) | Java | 7 | 0 | 2 | 9 |
| [src/VODTest.java](/src/VODTest.java) | Java | 44 | 39 | 31 | 114 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)