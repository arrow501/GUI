# Summary

Date : 2023-04-24 21:44:47

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 19 files,  334 codes, 39 comments, 92 blanks, all 465 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 18 | 324 | 39 | 83 | 446 |
| Markdown | 1 | 10 | 0 | 9 | 19 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 19 | 334 | 39 | 92 | 465 |
| . (Files) | 1 | 10 | 0 | 9 | 19 |
| bin | 9 | 128 | 0 | 1 | 129 |
| bin (Files) | 1 | 31 | 0 | 1 | 32 |
| bin\\Cennik | 2 | 36 | 0 | 0 | 36 |
| bin\\Dane | 5 | 55 | 0 | 0 | 55 |
| bin\\Gatunki | 1 | 6 | 0 | 0 | 6 |
| src | 9 | 196 | 39 | 82 | 317 |
| src (Files) | 1 | 44 | 39 | 31 | 114 |
| src\\Cennik | 2 | 71 | 0 | 22 | 93 |
| src\\Dane | 5 | 74 | 0 | 27 | 101 |
| src\\Gatunki | 1 | 7 | 0 | 2 | 9 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)