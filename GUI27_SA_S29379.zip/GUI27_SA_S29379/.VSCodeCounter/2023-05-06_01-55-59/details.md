# Details

Date : 2023-05-06 01:55:59

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 24 files,  650 codes, 57 comments, 135 blanks, all 842 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 10 | 0 | 9 | 19 |
| [bin/Cennik/Cennik.class](/bin/Cennik/Cennik.class) | Java | 34 | 0 | 0 | 34 |
| [bin/Cennik/CennikItem.class](/bin/Cennik/CennikItem.class) | Java | 16 | 0 | 0 | 16 |
| [bin/Klient/Klient.class](/bin/Klient/Klient.class) | Java | 48 | 0 | 0 | 48 |
| [bin/Klient/Koszyk.class](/bin/Klient/Koszyk.class) | Java | 12 | 0 | 0 | 12 |
| [bin/Klient/ListaZyczen.class](/bin/Klient/ListaZyczen.class) | Java | 28 | 0 | 1 | 29 |
| [bin/Programy/Gatunki/Dramat.class](/bin/Programy/Gatunki/Dramat.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Komedia.class](/bin/Programy/Gatunki/Komedia.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Obyczaj.class](/bin/Programy/Gatunki/Obyczaj.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Sensacja.class](/bin/Programy/Gatunki/Sensacja.class) | Java | 7 | 0 | 0 | 7 |
| [bin/Programy/Program.class](/bin/Programy/Program.class) | Java | 40 | 0 | 0 | 40 |
| [bin/VODTest.class](/bin/VODTest.class) | Java | 65 | 0 | 0 | 65 |
| [src/Cennik/Cennik.java](/src/Cennik/Cennik.java) | Java | 41 | 0 | 13 | 54 |
| [src/Cennik/CennikItem.java](/src/Cennik/CennikItem.java) | Java | 41 | 0 | 10 | 51 |
| [src/Klient/Klient.java](/src/Klient/Klient.java) | Java | 92 | 0 | 22 | 114 |
| [src/Klient/Koszyk.java](/src/Klient/Koszyk.java) | Java | 10 | 0 | 3 | 13 |
| [src/Klient/ListaZyczen.java](/src/Klient/ListaZyczen.java) | Java | 42 | 0 | 11 | 53 |
| [src/Programy/Gatunki/Dramat.java](/src/Programy/Gatunki/Dramat.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Komedia.java](/src/Programy/Gatunki/Komedia.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Obyczaj.java](/src/Programy/Gatunki/Obyczaj.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Sensacja.java](/src/Programy/Gatunki/Sensacja.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Program.java](/src/Programy/Program.java) | Java | 69 | 1 | 20 | 90 |
| [src/Programy/Programy.java](/src/Programy/Programy.java) | Java | 1 | 16 | 7 | 24 |
| [src/VODTest.java](/src/VODTest.java) | Java | 48 | 40 | 31 | 119 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)