# Diff Details

Date : 2023-05-06 01:55:59

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 35 files,  316 codes, 18 comments, 43 blanks, all 377 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [bin/Cennik/Cennik.class](/bin/Cennik/Cennik.class) | Java | 7 | 0 | 0 | 7 |
| [bin/Cennik/CennikItem.class](/bin/Cennik/CennikItem.class) | Java | 7 | 0 | 0 | 7 |
| [bin/Dane/Klient.class](/bin/Dane/Klient.class) | Java | -13 | 0 | 0 | -13 |
| [bin/Dane/Koszyk.class](/bin/Dane/Koszyk.class) | Java | -14 | 0 | 0 | -14 |
| [bin/Dane/ListaZyczen.class](/bin/Dane/ListaZyczen.class) | Java | -5 | 0 | 0 | -5 |
| [bin/Dane/Program.class](/bin/Dane/Program.class) | Java | -10 | 0 | 0 | -10 |
| [bin/Dane/Programy.class](/bin/Dane/Programy.class) | Java | -13 | 0 | 0 | -13 |
| [bin/Gatunki/Dramat.class](/bin/Gatunki/Dramat.class) | Java | -6 | 0 | 0 | -6 |
| [bin/Klient/Klient.class](/bin/Klient/Klient.class) | Java | 48 | 0 | 0 | 48 |
| [bin/Klient/Koszyk.class](/bin/Klient/Koszyk.class) | Java | 12 | 0 | 0 | 12 |
| [bin/Klient/ListaZyczen.class](/bin/Klient/ListaZyczen.class) | Java | 28 | 0 | 1 | 29 |
| [bin/Programy/Gatunki/Dramat.class](/bin/Programy/Gatunki/Dramat.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Komedia.class](/bin/Programy/Gatunki/Komedia.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Obyczaj.class](/bin/Programy/Gatunki/Obyczaj.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Sensacja.class](/bin/Programy/Gatunki/Sensacja.class) | Java | 7 | 0 | 0 | 7 |
| [bin/Programy/Program.class](/bin/Programy/Program.class) | Java | 40 | 0 | 0 | 40 |
| [bin/VODTest.class](/bin/VODTest.class) | Java | 34 | 0 | -1 | 33 |
| [src/Cennik/Cennik.java](/src/Cennik/Cennik.java) | Java | 6 | 0 | 0 | 6 |
| [src/Cennik/CennikItem.java](/src/Cennik/CennikItem.java) | Java | 5 | 0 | 1 | 6 |
| [src/Dane/Klient.java](/src/Dane/Klient.java) | Java | -16 | 0 | -5 | -21 |
| [src/Dane/Koszyk.java](/src/Dane/Koszyk.java) | Java | -9 | 0 | -2 | -11 |
| [src/Dane/ListaZyczen.java](/src/Dane/ListaZyczen.java) | Java | -3 | 0 | -3 | -6 |
| [src/Dane/Program.java](/src/Dane/Program.java) | Java | -29 | 0 | -10 | -39 |
| [src/Dane/Programy.java](/src/Dane/Programy.java) | Java | -17 | 0 | -7 | -24 |
| [src/Gatunki/Dramat.java](/src/Gatunki/Dramat.java) | Java | -7 | 0 | -2 | -9 |
| [src/Klient/Klient.java](/src/Klient/Klient.java) | Java | 92 | 0 | 22 | 114 |
| [src/Klient/Koszyk.java](/src/Klient/Koszyk.java) | Java | 10 | 0 | 3 | 13 |
| [src/Klient/ListaZyczen.java](/src/Klient/ListaZyczen.java) | Java | 42 | 0 | 11 | 53 |
| [src/Programy/Gatunki/Dramat.java](/src/Programy/Gatunki/Dramat.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Komedia.java](/src/Programy/Gatunki/Komedia.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Obyczaj.java](/src/Programy/Gatunki/Obyczaj.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Sensacja.java](/src/Programy/Gatunki/Sensacja.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Program.java](/src/Programy/Program.java) | Java | 69 | 1 | 20 | 90 |
| [src/Programy/Programy.java](/src/Programy/Programy.java) | Java | 1 | 16 | 7 | 24 |
| [src/VODTest.java](/src/VODTest.java) | Java | 4 | 1 | 0 | 5 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details