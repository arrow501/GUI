# Diff Summary

Date : 2023-05-06 01:55:59

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 35 files,  316 codes, 18 comments, 43 blanks, all 377 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 35 | 316 | 18 | 43 | 377 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 35 | 316 | 18 | 43 | 377 |
| bin | 17 | 140 | 0 | 0 | 140 |
| bin (Files) | 1 | 34 | 0 | -1 | 33 |
| bin\\Cennik | 2 | 14 | 0 | 0 | 14 |
| bin\\Dane | 5 | -55 | 0 | 0 | -55 |
| bin\\Gatunki | 1 | -6 | 0 | 0 | -6 |
| bin\\Klient | 3 | 88 | 0 | 1 | 89 |
| bin\\Programy | 5 | 65 | 0 | 0 | 65 |
| bin\\Programy (Files) | 1 | 40 | 0 | 0 | 40 |
| bin\\Programy\\Gatunki | 4 | 25 | 0 | 0 | 25 |
| src | 18 | 176 | 18 | 43 | 237 |
| src (Files) | 1 | 4 | 1 | 0 | 5 |
| src\\Cennik | 2 | 11 | 0 | 1 | 12 |
| src\\Dane | 5 | -74 | 0 | -27 | -101 |
| src\\Gatunki | 1 | -7 | 0 | -2 | -9 |
| src\\Klient | 3 | 144 | 0 | 36 | 180 |
| src\\Programy | 6 | 98 | 17 | 35 | 150 |
| src\\Programy (Files) | 2 | 70 | 17 | 27 | 114 |
| src\\Programy\\Gatunki | 4 | 28 | 0 | 8 | 36 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)