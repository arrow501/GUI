# Summary

Date : 2023-05-06 01:55:59

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 24 files,  650 codes, 57 comments, 135 blanks, all 842 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 23 | 640 | 57 | 126 | 823 |
| Markdown | 1 | 10 | 0 | 9 | 19 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 24 | 650 | 57 | 135 | 842 |
| . (Files) | 1 | 10 | 0 | 9 | 19 |
| bin | 11 | 268 | 0 | 1 | 269 |
| bin (Files) | 1 | 65 | 0 | 0 | 65 |
| bin\\Cennik | 2 | 50 | 0 | 0 | 50 |
| bin\\Klient | 3 | 88 | 0 | 1 | 89 |
| bin\\Programy | 5 | 65 | 0 | 0 | 65 |
| bin\\Programy (Files) | 1 | 40 | 0 | 0 | 40 |
| bin\\Programy\\Gatunki | 4 | 25 | 0 | 0 | 25 |
| src | 12 | 372 | 57 | 125 | 554 |
| src (Files) | 1 | 48 | 40 | 31 | 119 |
| src\\Cennik | 2 | 82 | 0 | 23 | 105 |
| src\\Klient | 3 | 144 | 0 | 36 | 180 |
| src\\Programy | 6 | 98 | 17 | 35 | 150 |
| src\\Programy (Files) | 2 | 70 | 17 | 27 | 114 |
| src\\Programy\\Gatunki | 4 | 28 | 0 | 8 | 36 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)