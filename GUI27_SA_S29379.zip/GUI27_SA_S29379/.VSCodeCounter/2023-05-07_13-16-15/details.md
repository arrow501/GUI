# Details

Date : 2023-05-07 13:16:15

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 23 files,  640 codes, 87 comments, 128 blanks, all 855 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 10 | 0 | 9 | 19 |
| [bin/Cennik/Cennik.class](/bin/Cennik/Cennik.class) | Java | 33 | 0 | 0 | 33 |
| [bin/Cennik/CennikItem.class](/bin/Cennik/CennikItem.class) | Java | 15 | 0 | 0 | 15 |
| [bin/Klient/Klient.class](/bin/Klient/Klient.class) | Java | 48 | 0 | 0 | 48 |
| [bin/Klient/Koszyk.class](/bin/Klient/Koszyk.class) | Java | 10 | 0 | 0 | 10 |
| [bin/Klient/ListaZyczen.class](/bin/Klient/ListaZyczen.class) | Java | 28 | 0 | 1 | 29 |
| [bin/Programy/Gatunki/Dramat.class](/bin/Programy/Gatunki/Dramat.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Komedia.class](/bin/Programy/Gatunki/Komedia.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Obyczaj.class](/bin/Programy/Gatunki/Obyczaj.class) | Java | 6 | 0 | 0 | 6 |
| [bin/Programy/Gatunki/Sensacja.class](/bin/Programy/Gatunki/Sensacja.class) | Java | 7 | 0 | 0 | 7 |
| [bin/Programy/Program.class](/bin/Programy/Program.class) | Java | 40 | 0 | 0 | 40 |
| [bin/VODTest.class](/bin/VODTest.class) | Java | 66 | 0 | 0 | 66 |
| [src/Cennik/Cennik.java](/src/Cennik/Cennik.java) | Java | 40 | 8 | 13 | 61 |
| [src/Cennik/CennikItem.java](/src/Cennik/CennikItem.java) | Java | 41 | 3 | 11 | 55 |
| [src/Klient/Klient.java](/src/Klient/Klient.java) | Java | 92 | 18 | 22 | 132 |
| [src/Klient/Koszyk.java](/src/Klient/Koszyk.java) | Java | 6 | 1 | 1 | 8 |
| [src/Klient/ListaZyczen.java](/src/Klient/ListaZyczen.java) | Java | 42 | 6 | 13 | 61 |
| [src/Programy/Gatunki/Dramat.java](/src/Programy/Gatunki/Dramat.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Komedia.java](/src/Programy/Gatunki/Komedia.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Obyczaj.java](/src/Programy/Gatunki/Obyczaj.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Gatunki/Sensacja.java](/src/Programy/Gatunki/Sensacja.java) | Java | 7 | 0 | 2 | 9 |
| [src/Programy/Program.java](/src/Programy/Program.java) | Java | 69 | 12 | 20 | 101 |
| [src/VODTest.java](/src/VODTest.java) | Java | 47 | 39 | 30 | 116 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)