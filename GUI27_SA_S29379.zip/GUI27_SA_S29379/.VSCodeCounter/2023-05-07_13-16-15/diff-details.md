# Diff Details

Date : 2023-05-07 13:16:15

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 12 files,  -10 codes, 30 comments, -7 blanks, all 13 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [bin/Cennik/Cennik.class](/bin/Cennik/Cennik.class) | Java | -1 | 0 | 0 | -1 |
| [bin/Cennik/CennikItem.class](/bin/Cennik/CennikItem.class) | Java | -1 | 0 | 0 | -1 |
| [bin/Klient/Koszyk.class](/bin/Klient/Koszyk.class) | Java | -2 | 0 | 0 | -2 |
| [bin/VODTest.class](/bin/VODTest.class) | Java | 1 | 0 | 0 | 1 |
| [src/Cennik/Cennik.java](/src/Cennik/Cennik.java) | Java | -1 | 8 | 0 | 7 |
| [src/Cennik/CennikItem.java](/src/Cennik/CennikItem.java) | Java | 0 | 3 | 1 | 4 |
| [src/Klient/Klient.java](/src/Klient/Klient.java) | Java | 0 | 18 | 0 | 18 |
| [src/Klient/Koszyk.java](/src/Klient/Koszyk.java) | Java | -4 | 1 | -2 | -5 |
| [src/Klient/ListaZyczen.java](/src/Klient/ListaZyczen.java) | Java | 0 | 6 | 2 | 8 |
| [src/Programy/Program.java](/src/Programy/Program.java) | Java | 0 | 11 | 0 | 11 |
| [src/Programy/Programy.java](/src/Programy/Programy.java) | Java | -1 | -16 | -7 | -24 |
| [src/VODTest.java](/src/VODTest.java) | Java | -1 | -1 | -1 | -3 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details