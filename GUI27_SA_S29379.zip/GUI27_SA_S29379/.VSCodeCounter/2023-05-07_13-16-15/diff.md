# Diff Summary

Date : 2023-05-07 13:16:15

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 12 files,  -10 codes, 30 comments, -7 blanks, all 13 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 12 | -10 | 30 | -7 | 13 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 12 | -10 | 30 | -7 | 13 |
| bin | 4 | -3 | 0 | 0 | -3 |
| bin (Files) | 1 | 1 | 0 | 0 | 1 |
| bin\\Cennik | 2 | -2 | 0 | 0 | -2 |
| bin\\Klient | 1 | -2 | 0 | 0 | -2 |
| src | 8 | -7 | 30 | -7 | 16 |
| src (Files) | 1 | -1 | -1 | -1 | -3 |
| src\\Cennik | 2 | -1 | 11 | 1 | 11 |
| src\\Klient | 3 | -4 | 25 | 0 | 21 |
| src\\Programy | 2 | -1 | -5 | -7 | -13 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)