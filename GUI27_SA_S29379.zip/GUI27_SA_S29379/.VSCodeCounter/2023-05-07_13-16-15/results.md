# Summary

Date : 2023-05-07 13:16:15

Directory c:\\Users\\alik5\\workspace\\GUI\\GUI27_SA_S29379

Total : 23 files,  640 codes, 87 comments, 128 blanks, all 855 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 22 | 630 | 87 | 119 | 836 |
| Markdown | 1 | 10 | 0 | 9 | 19 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 23 | 640 | 87 | 128 | 855 |
| . (Files) | 1 | 10 | 0 | 9 | 19 |
| bin | 11 | 265 | 0 | 1 | 266 |
| bin (Files) | 1 | 66 | 0 | 0 | 66 |
| bin\\Cennik | 2 | 48 | 0 | 0 | 48 |
| bin\\Klient | 3 | 86 | 0 | 1 | 87 |
| bin\\Programy | 5 | 65 | 0 | 0 | 65 |
| bin\\Programy (Files) | 1 | 40 | 0 | 0 | 40 |
| bin\\Programy\\Gatunki | 4 | 25 | 0 | 0 | 25 |
| src | 11 | 365 | 87 | 118 | 570 |
| src (Files) | 1 | 47 | 39 | 30 | 116 |
| src\\Cennik | 2 | 81 | 11 | 24 | 116 |
| src\\Klient | 3 | 140 | 25 | 36 | 201 |
| src\\Programy | 5 | 97 | 12 | 28 | 137 |
| src\\Programy (Files) | 1 | 69 | 12 | 20 | 101 |
| src\\Programy\\Gatunki | 4 | 28 | 0 | 8 | 36 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)