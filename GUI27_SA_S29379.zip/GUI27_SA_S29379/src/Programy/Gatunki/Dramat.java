package Programy.Gatunki;

import Programy.Program;

public class Dramat extends Program {
    static final String GENRE = "dramat";

    public Dramat(String title, int deviceCount) {
        super(title, GENRE, deviceCount);
    }
}