package Programy.Gatunki;

import Programy.Program;

public class Komedia extends Program {
    static final String GENRE = "komedia";

    public Komedia(String title, int deviceCount) {
        super(title, GENRE, deviceCount);
    }
}