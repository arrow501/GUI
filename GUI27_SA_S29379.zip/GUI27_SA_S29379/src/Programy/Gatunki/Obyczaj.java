package Programy.Gatunki;

import Programy.Program;

public class Obyczaj extends Program {
    static final String GENRE = "obyczaj";

    public Obyczaj(String title, int deviceCount) {
        super(title, GENRE, deviceCount);
    }
}