package Programy.Gatunki;

import Programy.Program;

public class Sensacja extends Program {
    static final String GENRE = "sensacja";

    public Sensacja(String title, int deviceCount) {
        super(title, GENRE, deviceCount);
    }
}